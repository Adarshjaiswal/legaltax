<?php
$host ="http://localhost/Certificate/";
$main_url=$host."";
$my_css = $main_url."assests/css/style.css";
$bootstrap_min = $main_url."assests/css/bootstrap.min.css";
$boot_js = $main_url."assests/js/bootstrap.min.js";
$jquery_min = $main_url."assests/js/jquery.min.js";
$font_awes= $main_url."assests/font/css/all.css";
$global_image=$main_url."assests/image/";
$global_upload_image="http://localhost/Certificate/uploads/";
?>